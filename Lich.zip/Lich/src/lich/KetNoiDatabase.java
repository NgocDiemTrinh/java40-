package lich;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class KetNoiDatabase {
    private static Connection connection;
    private static final String DB_URL = "jdbc:sqlserver://localhost:1433; databaseName=QuanLyLichCongViec";
    private static final String DB_USER = "Trinh";
    private static final String DB_PASSWORD = "2210";

   public static Connection getConnection() {
        try {
            return DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
        } catch (SQLException e) {
            e.printStackTrace();
            return null;
        }
    }

    public static void closeConnection(Connection connection) {
        try {
            if (connection != null) {
                connection.close();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}