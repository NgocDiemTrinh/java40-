package lich;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;

public class DBEmail {
     private Connection ketnoi;

    public DBEmail() {
        this.ketnoi = KetNoiDatabase.getConnection();
    }

    public void insert(String email, String password) {
        try (CallableStatement thutuc = ketnoi.prepareCall("{call sp_Email_Insert(?,?)}")) {
            thutuc.setString(1, email);
            thutuc.setString(2, password);

            thutuc.execute();

        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Lỗi: " + ex.getMessage());
        }
    }

    public Email getEmail() {
        Email mailGui = new Email();
        try (CallableStatement thutuc = ketnoi.prepareCall("{call sp_Email_SelectAll()}")) {
            thutuc.execute();
            ResultSet resultSet = thutuc.getResultSet();

            while (resultSet.next()) {
                String email = resultSet.getString("Email");
                String password = resultSet.getString("Password");
              
                mailGui.setEmail(email);
                mailGui.setPass(password);              
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Lỗi: " + ex.getMessage());
        }
        return mailGui;
    }
}
