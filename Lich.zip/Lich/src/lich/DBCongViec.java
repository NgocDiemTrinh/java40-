/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package lich;

import java.sql.Connection;
import java.sql.CallableStatement;
import java.util.Date;
import java.sql.SQLException;
import java.util.logging.Logger;
import java.util.logging.Level;
import java.time.LocalDateTime;
import java.sql.Timestamp;
import java.util.List;
import java.util.ArrayList;
import java.sql.ResultSet;
import java.text.ParseException;
import java.text.SimpleDateFormat;
/**
 *
 * @author ASUS
 */
public class DBCongViec {
    private Connection ketnoi;

    public DBCongViec() {
        this.ketnoi = KetNoiDatabase.getConnection();
    }

    public void insert(String DsUserID, Boolean TienDo, String CongViec, String NgayBatDau, String GioBatDau, String NgayKetThuc, String GioKetThuc) {
        try (CallableStatement thutuc = ketnoi.prepareCall("{call sp_CongViec_Insert(?,?,?,?,?,?,?)}")) {
            thutuc.setString(1, CongViec);
            thutuc.setBoolean(2, TienDo);
            thutuc.setString(3, NgayBatDau);
            thutuc.setString(4, GioBatDau);
            thutuc.setString(5, NgayKetThuc);
            thutuc.setString(6, GioKetThuc);
            thutuc.setString(7, DsUserID);
            
            thutuc.execute();

        } catch (SQLException ex) {
            Logger.getLogger(DBTaiKhoan.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void update(String dsUserID, String TienDo, String CongViec, String NgayBatDau, String GioBatDau, String NgayKetThuc, String GioKetThuc) {
        try (CallableStatement thutuc = ketnoi.prepareCall("{call sp_CongViec_Update(?,?,?,?,?,?,?)}")) {
            thutuc.setString(1, dsUserID);
            thutuc.setString(2, TienDo);
            thutuc.setString(3, CongViec);
            thutuc.setString(4, NgayBatDau);
            thutuc.setString(5, GioBatDau);
            thutuc.setString(6, NgayKetThuc);
            thutuc.setString(7, GioKetThuc);
            thutuc.execute();

        } catch (SQLException ex) {
            Logger.getLogger(DBTaiKhoan.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void delete(String ID) {
        try (CallableStatement thutuc = ketnoi.prepareCall("{call sp_CongViec_Delete(?)}")) {
            thutuc.setString(1, ID);
            thutuc.execute();

        } catch (SQLException ex) {
            Logger.getLogger(DBTaiKhoan.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public List<CongViec> selectByDate(String ngayChon){
        List<CongViec> dsCongViec=new ArrayList<>();
        try (CallableStatement thutuc = ketnoi.prepareCall("{call sp_CongViec_Select_TheoNgay(?)}")) {
            
            thutuc.setString(1, ngayChon);
            thutuc.execute();
            ResultSet ketquaSQL= thutuc.getResultSet();
            while(ketquaSQL.next()){
                String tenCongViec=ketquaSQL.getString("TenCongViec");
                Boolean tienDo=ketquaSQL.getBoolean("TienDo");
                String ngayBatDau=ketquaSQL.getString("NgayBatDau");
                String gioBatDau=ketquaSQL.getString("GioBatDau");
                String ngayKetThuc=ketquaSQL.getString("NgayKetThuc");
                String gioKetThuc=ketquaSQL.getString("GioKetThuc");
                String userID=ketquaSQL.getString("NguoiLam");

                
                CongViec cv = new CongViec();
                cv.setTenCongViec(tenCongViec);
                cv.setTienDo(tienDo);
                cv.setNgayBatDau(ngayBatDau);
                cv.setGioBatDau(gioBatDau);
                cv.setNgayKetThuc(ngayKetThuc);
                cv.setGioKetThuc(gioKetThuc);
                cv.setUserID(userID);
                
                dsCongViec.add(cv);
                
            }
            
        } catch (SQLException ex) {
            Logger.getLogger(DBCongViec.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        return dsCongViec;
    }
    
    public List<CongViec> select(){
        List<CongViec> dsCongViec=new ArrayList<>();
        try (CallableStatement thutuc = ketnoi.prepareCall("{call sp_CongViec_SelectAll()}")) {
 
            thutuc.execute();
            ResultSet ketquaSQL= thutuc.getResultSet();
            while(ketquaSQL.next()){
                String tenCongViec=ketquaSQL.getString("TenCongViec");
                Boolean tienDo=ketquaSQL.getBoolean("TienDo");
                String ngayBatDau=ketquaSQL.getString("NgayBatDau");
                String gioBatDau=ketquaSQL.getString("GioBatDau");
                String ngayKetThuc=ketquaSQL.getString("NgayKetThuc");
                String gioKetThuc=ketquaSQL.getString("GioKetThuc");
                String userID=ketquaSQL.getString("NguoiLam");

                
                CongViec cv = new CongViec();
                cv.setTenCongViec(tenCongViec);
                cv.setTienDo(tienDo);
                cv.setNgayBatDau(ngayBatDau);
                cv.setGioBatDau(gioBatDau);
                cv.setNgayKetThuc(ngayKetThuc);
                cv.setGioKetThuc(gioKetThuc);
                cv.setUserID(userID);
                
                dsCongViec.add(cv);
                
            }
            
        } catch (SQLException ex) {
            Logger.getLogger(DBCongViec.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        return dsCongViec;
    }
}
