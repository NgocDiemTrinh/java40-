/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package lich;

import java.util.List;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.CallableStatement;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.sql.ResultSet;
import javax.swing.JOptionPane;

/**
 *
 * @author ASUS
 */
public class DBTaiKhoan {

    private Connection ketnoi;

    public DBTaiKhoan() {
        this.ketnoi = KetNoiDatabase.getConnection();
    }

    public void insert(String ID, String MatKhau, String HoTen, String Email, Boolean Quyen) {
        try (CallableStatement thutuc = ketnoi.prepareCall("{call sp_TaiKhoan_Insert(?,?,?,?,?)}")) {
            thutuc.setString(1, ID);
            thutuc.setString(2, MatKhau);
            thutuc.setString(3, HoTen);
            thutuc.setString(4, Email);
            thutuc.setBoolean(5, Quyen);
            thutuc.execute();

        } catch (SQLException ex) {
            Logger.getLogger(DBTaiKhoan.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void update(String ID, String MatKhau, String HoTen, String Email, Boolean Quyen) {
        try (CallableStatement thutuc = ketnoi.prepareCall("{call sp_TaiKhoan_Update(?,?,?,?,?)}")) {
            thutuc.setString(1, ID);
            thutuc.setString(2, MatKhau);
            thutuc.setString(3, HoTen);
            thutuc.setString(4, Email);
            thutuc.setBoolean(5, Quyen);
            thutuc.execute();

        } catch (SQLException ex) {
            Logger.getLogger(DBTaiKhoan.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void delete(String ID) {
        try (CallableStatement thutuc = ketnoi.prepareCall("{call sp_TaiKhoan_Delete(?)}")) {
            thutuc.setString(1, ID);
            thutuc.execute();

        } catch (SQLException ex) {
            Logger.getLogger(DBTaiKhoan.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public List<TaiKhoan> select(){
        List<TaiKhoan> dsTaiKhoan=new ArrayList<>();
        try (CallableStatement thutuc = ketnoi.prepareCall("{call sp_TaiKhoan_SelectAll()}")) {
            
            thutuc.execute();
            ResultSet ketquaSQL= thutuc.getResultSet();
            while(ketquaSQL.next()){
                String ID=ketquaSQL.getString("UserID");
                String MatKhau=ketquaSQL.getString("MatKhau");
                String HoTen=ketquaSQL.getString("HoTen");
                String Email=ketquaSQL.getString("Email");
                Boolean Quyen=ketquaSQL.getBoolean("Quyen");

                
                TaiKhoan tk = new TaiKhoan();
                tk.setID(ID);
                tk.setMatKhau(MatKhau);
                tk.setHoTen(HoTen);
                tk.setEmail(Email);
                tk.setQuyen(Quyen);
                
                dsTaiKhoan.add(tk);
                
            }
            
        } catch (SQLException ex) {
            Logger.getLogger(DBTaiKhoan.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        
        return dsTaiKhoan;
    }
    
    public boolean login(String ID, String MatKhau){
        Boolean kqLogin=false;
        try (CallableStatement thutuc = ketnoi.prepareCall("{call sp_TaiKhoan_CheckLogin(?,?)}")) {
            thutuc.setString(1, ID);
            thutuc.setString(2, MatKhau);
            thutuc.execute();
            ResultSet ketquaSQL= thutuc.getResultSet();
            while(ketquaSQL.next()){
                kqLogin=ketquaSQL.getBoolean("KetQua");
                if(kqLogin==true){
                    String hoten=ketquaSQL.getString("HoTen");
                    Boolean quyen=ketquaSQL.getBoolean("Quyen");
                    
                    TaiKhoan tk = new TaiKhoan();
                    tk.setID(ID);
                    //tk.setMatKhau(MatKhau);
                    tk.setHoTen(hoten);
                    tk.setQuyen(quyen);

                    BoNhoTam.setUser(tk);
                }

            }
            
        } catch (SQLException ex) {
            //Logger.getLogger(DBTaiKhoan.class.getName()).log(Level.SEVERE, null, ex);
            JOptionPane.showMessageDialog(null, "Loi sql login: "+ex.getMessage());
        }
        return kqLogin;
    }
}
