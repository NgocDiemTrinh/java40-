package lich;

public class CongViec {
    private String UserID;
    private String TenCongViec;
    private Boolean TienDo;
    private String NgayBatDau;
    private String GioBatDau;
    private String NgayKetThuc;
    private String GioKetThuc;

    public String getUserID() {
        return UserID;
    }

    public void setUserID(String UserID) {
        this.UserID = UserID;
    }

    public String getTenCongViec() {
        return TenCongViec;
    }

    public void setTenCongViec(String TenCongViec) {
        this.TenCongViec = TenCongViec;
    }

    public Boolean getTienDo() {
        return TienDo;
    }

    public void setTienDo(Boolean TienDo) {
        this.TienDo = TienDo;
    }

    public String getNgayBatDau() {
        return NgayBatDau;
    }

    public void setNgayBatDau(String NgayBatDau) {
        this.NgayBatDau = NgayBatDau;
    }

    public String getGioBatDau() {
        return GioBatDau;
    }

    public void setGioBatDau(String GioBatDau) {
        this.GioBatDau = GioBatDau;
    }

    public String getNgayKetThuc() {
        return NgayKetThuc;
    }

    public void setNgayKetThuc(String NgayKetThuc) {
        this.NgayKetThuc = NgayKetThuc;
    }

    public String getGioKetThuc() {
        return GioKetThuc;
    }

    public void setGioKetThuc(String GioKetThuc) {
        this.GioKetThuc = GioKetThuc;
    }

    

    
}
